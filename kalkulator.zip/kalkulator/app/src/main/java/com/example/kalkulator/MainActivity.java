package com.example.kalkulator;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    TextView angka1, operator, angka2;
    int a=0, b=0;
    Button tb1, tb2, tb3, tb4,tb5,tb6,tb7,tb8,tb9,tb0, sama_dengan, tambah,kurang,kali,bagi, bersih;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        angka1 = findViewById(R.id.angka1);
        angka2 = findViewById(R.id.angka2);
        operator = findViewById(R.id.operator);
        tb1= findViewById(R.id.tb1);
        tb2= findViewById(R.id.tb2);
        tb3= findViewById(R.id.tb3);
        tb4= findViewById(R.id.tb4);
        tb5= findViewById(R.id.tb5);
        tb6= findViewById(R.id.tb6);
        tb7= findViewById(R.id.tb7);
        tb8= findViewById(R.id.tb8);
        tb9= findViewById(R.id.tb9);
        tb0= findViewById(R.id.tb0);
        sama_dengan= findViewById(R.id.sama_dengan);
        tambah= findViewById(R.id.ak1);
        kurang= findViewById(R.id.ak2);
        kali= findViewById(R.id.ak3);
        bagi= findViewById(R.id.ak4);
        bersih= findViewById(R.id.bersih);

        tb1.setOnClickListener(this);
        tb2.setOnClickListener(this);
        tb3.setOnClickListener(this);
        tb4.setOnClickListener(this);
        tb5.setOnClickListener(this);
        tb6.setOnClickListener(this);
        tb7.setOnClickListener(this);
        tb8.setOnClickListener(this);
        tb9.setOnClickListener(this);
        tb0.setOnClickListener(this);
        tambah.setOnClickListener(this);
        kurang.setOnClickListener(this);
        kali.setOnClickListener(this);
        bagi.setOnClickListener(this);
        bersih.setOnClickListener(this);
        sama_dengan.setOnClickListener(this);

    }


    @Override
    public void onClick(View v) {

        switch (v.getId()){
            case R.id.tb1:
                isi("1");
                break;
            case R.id.tb2:
                isi("2");
                break;
            case R.id.tb3:
                isi("3");
                break;
            case R.id.tb4:
                isi("4");
                break;
            case R.id.tb5:
                isi("5");
                break;
            case R.id.tb6:
                isi("6");
                break;
            case R.id.tb7:
                isi("7");
                break;
            case R.id.tb8:
                isi("8");
                break;
            case R.id.tb9:
                isi("9");
                break;
            case R.id.tb0:
                isi("0");
                break;

//                aksi operator
            case R.id.ak1:
                aksi("+");
                break;
            case R.id.ak2:
                aksi("-");
                break;
            case R.id.ak3:
                aksi("*");
                break;
            case R.id.ak4:
                aksi("/");
                break;

//                aksi lainnya
            case R.id.bersih:
                bersih();
                break;
            case R.id.sama_dengan:
                hasil();
                break;
        }
    }



    private void isi(String s) {
        String op = operator.getText().toString();
        String a1 = angka1.getText().toString();
        String a2 = angka2.getText().toString();
        if(op==""){
            angka1.setText(a1+s);
        }else{
            angka2.setText(a2+s);
        }
    }

    private void aksi(String ak) {
        operator.setText("");
        operator.setText(ak);
    }
    private void hasil() {
        String a = operator.getText().toString();
        String nilai1 = angka1.getText().toString();
        String nilai2 = angka2.getText().toString();
        int n1 = Integer.parseInt(nilai1);
        int n2 = Integer.parseInt(nilai2);
        bersih();
        if (a=="+"){
            int c = n1+n2;
            isi(""+c);
        }else if (a=="-"){
            int c = n1-n2;
            isi(""+c);
        }else if (a=="*"){
            int c = n1*n2;
            isi(""+c);
        }else if (a=="/"){
            int c = n1/n2;
            isi(""+c);
        }


    }

    private void bersih() {
        angka1.setText("");
        angka2.setText("");
        operator.setText("");
    }
}